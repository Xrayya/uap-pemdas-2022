public interface TreatmentInterface {
    public void treatment(Medicine medicine);
    public void reduceDrugDuration();
}
