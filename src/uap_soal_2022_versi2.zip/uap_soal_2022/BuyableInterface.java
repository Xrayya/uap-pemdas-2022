public interface BuyableInterface {
    public String getName();
    public double getPricePerUnit();
    public void addResource(int add);
}
